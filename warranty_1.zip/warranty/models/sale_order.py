from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    has_warranty_available = fields.Boolean(
        string="Has Warranty Available",
        compute="_compute_has_warranty_available",
        store=False
    )

    @api.depends('order_line.product_id')
    def _compute_has_warranty_available(self):
        for order in self:
            order.has_warranty_available = any(
                line.product_id.is_warranty_available for line in order.order_line
            )

    def add_warranty(self, product_id, warranty_years):
        self.ensure_one()
        warranty_product = self.env['product.product'].browse(product_id)
        warranty_config = self.env['warranty.config'].browse(warranty_years)
        warranty_price = self.amount_untaxed * (warranty_config.percentage / 100)
        self.order_line.create({
            'product_id': warranty_product.id,
            'name': warranty_config.name,
            'price_unit': warranty_price,
            'product_uom_qty': 1,
        })
    