from odoo import models, fields, api
from dateutil.relativedelta import relativedelta


class WarrantyWizard(models.TransientModel):
    _name = 'warranty.wizard'

    product_id = fields.Many2one('product.product', string="Product", required=True)
    warranty_years = fields.Many2one('warranty.config', string="Warranty Configuration", required=True)
    end_date = fields.Date(compute='_compute_end_date', store=False)

    @api.depends('warranty_years')
    def _compute_end_date(self):
        for record in self:
            if record.warranty_years:
                record.end_date = fields.Date.today() + relativedelta(years=record.warranty_years.years)
            else:
                record.end_date = False


    def add_warranty(self):
        sale_order = self.env['sale.order'].browse(self._context.get('active_id'))
        warranty_line_vals = {
            'product_id': self.product_id.id,
            'name': self.warranty_years.name,
            'product_uom_qty': 1.0,
            'price_unit': sale_order.amount_untaxed * (self.warranty_years.percentage / 100),
            'order_id': sale_order.id
        }
        sale_order.order_line.create(warranty_line_vals)