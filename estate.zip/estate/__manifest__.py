{
    "name": "Real Estate",
    "version": "1.0",
    "sequence": 1,
    "depends": ["base"],
    "description": """
    This is the estate application being developed as per Tutorial for Technical Training.
    """,
    "installable": True,
    "application": True,
}
