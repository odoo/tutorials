{
    'name': "estate",
    'depends': ['base'],
    'author': "Ayush Kumar Singh",
    'application': True
    
}
# SHA256:Hmym4hCb2IR8asKknQs4KfejqLJ6MOota2asZe9IQTU akus@odoo.com
