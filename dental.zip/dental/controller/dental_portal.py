from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal

class DentalPortal(CustomerPortal):
    @http.route('/my/dental', type='http', auth='user', website=True)
    def portal_my_dental(self, **kw):
        guarantor_id = request.env.user.partner_id.id
        patients = request.env['dental.patient'].search([]).guarantor_id
        return request.render('dental.portal_my_dental', {
            'patients': patients
        })

    @http.route('/my/dental/<int:patient_id>', type='http', auth='user', website=True)
    def portal_my_dental_user(self, patient_id, **kw):
        patient = request.env['dental.patient'].browse(patient_id)
        return request.render('dental.portal_my_dental_user', {
            'patient': patient
        })

    @http.route('/my/dental/<int:patient_id>/personal', type='http', auth='user', website=True)
    def portal_my_dental_personal(self, patient_id, **kw):
        patient = request.env['dental.patient'].browse(patient_id)
        return request.render('dental.portal_my_dental_personal', {
            'patient': patient
        })

    @http.route('/my/dental/<int:patient_id>/medical_history', type='http', auth='user', website=True)
    def portal_my_dental_medical_history(self, patient_id, **kw):
        patient = request.env['dental.patient'].browse(patient_id)
        medical_history = patient.patient_history_ids
        return request.render('dental.portal_my_dental_medical_history', {
            'medical_history': medical_history
        })

    @http.route('/my/dental/<int:patient_id>/medical_aid', type='http', auth='user', website=True)
    def portal_my_dental_medical_aid(self, patient_id, **kw):
        patient = request.env['dental.patient'].browse(patient_id)
        medical_aid = {
            'medical_aid_id': patient.medical_aid_id,
            'medical_aid_plan': patient.medical_aid_plan,
            'medical_aid_number': patient.medical_aid_number,
            'main_number_code': patient.main_number_code,
            'dependant_code': patient.dependant_code
        }
        return request.render('dental.portal_my_dental_medical_aid', {
            'medical_aid': medical_aid
        })
