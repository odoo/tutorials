from . import dental_patients
from . import medical_aids
from . import medical_symptoms
from . import medication
from . import dental_patient_history
