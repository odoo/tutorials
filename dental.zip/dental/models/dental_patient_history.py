from odoo import models, fields, api
from datetime import date


class DentalPatientHistory(models.Model):
    _name = 'dental.patient.history'
    _description = 'Dental Patient History'

    # Basic information
    name = fields.Char(string="Title", required=True)
    description = fields.Text(string="Description")
    patient_id = fields.Many2one('dental.patient', string="Patient", required=True)
    date = fields.Date(string="Date", default=fields.Date.context_today, required=True)
    main_complaint = fields.Text(string="Main Complaint")
    history = fields.Text(string="History")
    company_id = fields.Many2one('res.company', string='Company')
    did_not_attend = fields.Boolean(string="Did Not Attend")
    tags = fields.Char(string="Tags")

    # X-ray file uploads
    xray_file_1 = fields.Binary(string="X-ray File 1")
    xray_file_2 = fields.Binary(string="X-ray File 2")
    clear_aligner_file_1 = fields.Binary(string="Clear Aligner File 1")
    clear_aligner_file_2 = fields.Binary(string="Clear Aligner File 2")

    # Other details
    habits = fields.Text(string="Habits")
    extra_oral_observation = fields.Text(string="Extra-Oral Observation")

    # Tooth chart (for example purposes)
    teeth_chart = fields.Char(string="Teeth Chart")

    # Treatment notes
    treatment_notes = fields.Text(string="Treatment Notes")

    # Billing information
    consultation_type = fields.Selection([
        ('full_consultation', 'Full Consultation with Bitewings and Scan'),
        ('basic_consultation', 'Basic Consultation'),
        ('no_consultation', 'No Consultation')
    ], string="Consultation Type")

    call_out = fields.Boolean(string="Call Out")
    scale_and_polish = fields.Boolean(string="Scale and Polish")
    fluoride = fields.Boolean(string="Fluoride")

    filling_description = fields.Text(string="Filling Description")

    aligner_delivery = fields.Boolean(
        string="Aligner Delivery and Attachment Placed")
    whitening = fields.Boolean(string="Whitening")

    fissure_sealant_qty = fields.Float(
        string="Fissure Sealant Quantity", digits=(6, 2))

    attachments_removed = fields.Boolean(string="Attachments Removed")
    aligner_followup_scan = fields.Boolean(string="Aligner Follow-up Scan")

    other_notes = fields.Text(string="Other Notes")

    # General notes field at the end
    notes = fields.Text(string="Additional Notes")

    @api.depends("patient_id")
    def _compute_name(self):
        for record in self:
            record.name = f"{record.patient_id.name}-{date.today()}"

    def action_save_close(self):
        # Method to save and close the form view
        self.ensure_one()
        self.env['ir.actions.act_window'].browse(self._context.get('active_id')).write({'state': 'done'})
