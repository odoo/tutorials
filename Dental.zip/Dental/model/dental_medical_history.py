from odoo import models, fields,api
from datetime import date

class DentalMedicalHistory(models.Model):
    _name = 'dental.medical.history'
    _description = 'Dental Medical History'

    history_id = fields.Many2one('dental.patient', string="History")
    # name = fields.Char(string="Name", store=True)
    # patient_id = fields.Many2one('dental.patient', string="Patient", required=True)
    # responsible_id = fields.Many2one('res.users', string="Responsible", default=lambda self: self.env.user)
    # date = fields.Date(string="Date", default=date.today())
    # description = fields.Text(string="Description")
    # did_not_attend = fields.Boolean(string="Did not attend")
    # company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)
    # main_complaint = fields.Text(string="Main Complaint")
    # teeth_history = fields.Text(string="History")
    # habits = fields.Text(string="Habits")
    # extra_oral_observation = fields.Text(string="Extra-Oral Observation")
    # xray_file_1 = fields.Image(string="X-ray file 1")
    # xray_file_2 = fields.Image(string="X-ray file 2")
    # clear_align_file_1 = fields.Binary(string="Clear Aligner File 1")
    # clear_align_file_2 = fields.Binary(string="Clear Aligner File 2")
    
    
    name = fields.Char(string='Name', required=True)
    patient_id = fields.Many2one('res.partner', string='Patient', required=True)
    responsible_id = fields.Many2one('res.users', string='Responsible', required=True)
    date = fields.Date(string='Date', default=fields.Date.today, required=True)
    did_not_attend = fields.Boolean(string='Did not attend')
    tags = fields.Many2many('patient.tags', string='Tags')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    # Teeth History Fields
    main_complaint = fields.Text(string='Main Complaint')
    teeth_history = fields.Text(string='History')
    xray_file_1 = fields.Binary(string='X-ray file 1')
    xray_file_2 = fields.Binary(string='X-ray file 2')
    
    # Other Fields
    habits = fields.Text(string='Habits')
    extra_oral_observation = fields.Text(string='Extra-Oral Observation')
    clear_aligner_file_1 = fields.Binary(string='Clear Aligner File 1')
    clear_aligner_file_2 = fields.Binary(string='Clear Aligner File 2')
    

    @api.depends('patient_id', 'date')
    def _compute_name(self):
        for record in self:
            record.name = f"{record.patient_id.name} - {record.date}" if record.patient_id and record.date else "New History"
