from . import dental_patients
from . import dental_medical_aids
from . import dental_medical_symptoms_chronic_conditions
from . import dental_medical_symptoms_habit
from . import dental_medical_symptoms_allergies
from . import dental_medication
from . import dental_medical_history
