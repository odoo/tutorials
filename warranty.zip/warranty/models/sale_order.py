from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    has_warranty_available = fields.Boolean(
        string="Has Warranty Available",
        compute="_compute_has_warranty_available",
        store=False
    )

    @api.depends('order_line.product_id')
    def _compute_has_warranty_available(self):
        for order in self:
            order.has_warranty_available = any(
                line.product_id.is_warranty_available for line in order.order_line
            )
